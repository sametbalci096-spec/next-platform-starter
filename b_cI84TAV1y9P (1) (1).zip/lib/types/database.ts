export interface Profile {
  id: string
  username: string
  display_name: string | null
  avatar_url: string | null
  bio: string | null
  created_at: string
  updated_at: string
}

export interface Topic {
  id: string
  title: string
  slug: string
  definition: string | null
  created_by: string | null
  created_at: string
  updated_at: string
  entry_count: number
  view_count: number
}

export interface Entry {
  id: string
  topic_id: string
  user_id: string
  content: string
  video_url: string | null
  like_count: number
  comment_count: number
  created_at: string
  updated_at: string
}

export interface EntryWithRelations extends Entry {
  profiles: Profile
  topics: Topic
  likes?: { user_id: string }[]
}

export interface Comment {
  id: string
  entry_id: string
  user_id: string
  content: string
  created_at: string
  updated_at: string
}

export interface CommentWithProfile extends Comment {
  profiles: Profile
}

export interface Like {
  id: string
  entry_id: string
  user_id: string
  created_at: string
}

export interface Follow {
  id: string
  follower_id: string
  following_id: string
  created_at: string
}

export interface PersonalWord {
  id: string
  user_id: string
  word: string
  definition: string
  video_url: string | null
  created_at: string
  updated_at: string
}

export interface CommunityWord {
  id: string
  word: string
  slug: string
  definition: string
  video_url: string | null
  created_by: string | null
  like_count: number
  created_at: string
  updated_at: string
}

export interface CommunityWordWithProfile extends CommunityWord {
  profiles: Profile | null
  community_word_likes?: { user_id: string }[]
}

export interface TopicWithEntries extends Topic {
  entries: EntryWithRelations[]
}
