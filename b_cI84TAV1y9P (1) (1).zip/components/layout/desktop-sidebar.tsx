'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Home, TrendingUp, Users, Languages, BookOpen, User, Plus, LogOut, Moon, Sun, Monitor } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useAuth } from '@/lib/context/auth-context'
import { useTheme } from '@/lib/context/theme-context'

const navItems = [
  { href: '/', icon: Home, label: 'Ana Sayfa' },
  { href: '/trending', icon: TrendingUp, label: 'Trend' },
  { href: '/following', icon: Users, label: 'Takip Ettiklerim' },
  { href: '/translate', icon: Languages, label: 'Çeviri' },
  { href: '/dictionary', icon: BookOpen, label: 'Sözlük' },
  { href: '/profile', icon: User, label: 'Profil' },
]

const themeOptions = [
  { value: 'light' as const, icon: Sun, label: 'Açık' },
  { value: 'dark' as const, icon: Moon, label: 'Koyu' },
  { value: 'system' as const, icon: Monitor, label: 'Sistem' },
]

export function DesktopSidebar() {
  const pathname = usePathname()
  const { user, profile, signOut } = useAuth()
  const { theme, setTheme } = useTheme()

  return (
    <aside className="hidden md:flex flex-col fixed left-0 top-0 h-screen w-64 bg-card border-r border-border p-4">
      <Link href="/" className="flex items-center gap-2 px-3 py-4 mb-4">
        <BookOpen className="h-8 w-8 text-primary" />
        <span className="text-xl font-bold text-foreground">Sözlüks</span>
      </Link>

      <nav className="flex-1 space-y-1">
        {navItems.map((item) => {
          const isActive = pathname === item.href || 
            (item.href !== '/' && pathname.startsWith(item.href))
          
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors',
                isActive 
                  ? 'bg-primary text-primary-foreground' 
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground'
              )}
            >
              <item.icon className="h-5 w-5" />
              <span className="font-medium">{item.label}</span>
            </Link>
          )
        })}

        {user && (
          <Link
            href="/entry/new"
            className="flex items-center gap-3 px-3 py-2.5 mt-4 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
          >
            <Plus className="h-5 w-5" />
            <span className="font-medium">Yeni Entry</span>
          </Link>
        )}
      </nav>

      <div className="border-t border-border pt-4 space-y-4">
        <div className="flex items-center justify-between px-3">
          <span className="text-sm text-muted-foreground">Tema</span>
          <div className="flex items-center gap-1 bg-muted rounded-lg p-1">
            {themeOptions.map((option) => (
              <button
                key={option.value}
                onClick={() => setTheme(option.value)}
                className={cn(
                  'p-1.5 rounded-md transition-colors',
                  theme === option.value
                    ? 'bg-background text-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                )}
                title={option.label}
              >
                <option.icon className="h-4 w-4" />
              </button>
            ))}
          </div>
        </div>

        {user ? (
          <div className="space-y-2">
            <Link
              href="/profile"
              className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-muted transition-colors"
            >
              <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center text-primary font-medium">
                {profile?.display_name?.[0]?.toUpperCase() || profile?.username?.[0]?.toUpperCase() || 'U'}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">
                  {profile?.display_name || profile?.username}
                </p>
                <p className="text-xs text-muted-foreground truncate">@{profile?.username}</p>
              </div>
            </Link>
            <button
              onClick={signOut}
              className="flex items-center gap-3 px-3 py-2 w-full text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg transition-colors"
            >
              <LogOut className="h-5 w-5" />
              <span className="font-medium">Çıkış Yap</span>
            </button>
          </div>
        ) : (
          <Link
            href="/auth/login"
            className="flex items-center justify-center gap-2 px-3 py-2.5 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
          >
            <span className="font-medium">Giriş Yap</span>
          </Link>
        )}
      </div>
    </aside>
  )
}
