'use client'

import { BottomNavigation } from './bottom-navigation'
import { DesktopSidebar } from './desktop-sidebar'
import { Header } from './header'

interface MainLayoutProps {
  children: React.ReactNode
}

export function MainLayout({ children }: MainLayoutProps) {
  return (
    <div className="min-h-screen bg-background">
      <DesktopSidebar />
      <div className="md:ml-64">
        <Header />
        <main className="min-h-screen">
          {children}
        </main>
      </div>
      <BottomNavigation />
    </div>
  )
}
