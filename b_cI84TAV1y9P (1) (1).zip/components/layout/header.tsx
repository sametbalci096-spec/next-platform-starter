'use client'

import Link from 'next/link'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { BookOpen, Search, X, Moon, Sun, LogIn } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useAuth } from '@/lib/context/auth-context'
import { useTheme } from '@/lib/context/theme-context'

export function Header() {
  const [searchQuery, setSearchQuery] = useState('')
  const [showSearch, setShowSearch] = useState(false)
  const router = useRouter()
  const { user, profile } = useAuth()
  const { resolvedTheme, setTheme } = useTheme()

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchQuery.trim())}`)
      setShowSearch(false)
      setSearchQuery('')
    }
  }

  const toggleTheme = () => {
    setTheme(resolvedTheme === 'dark' ? 'light' : 'dark')
  }

  return (
    <header className="sticky top-0 z-40 bg-card/80 backdrop-blur-lg border-b border-border md:hidden">
      <div className="flex items-center justify-between h-14 px-4">
        {showSearch ? (
          <form onSubmit={handleSearch} className="flex-1 flex items-center gap-2">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Başlık veya kelime ara..."
                className="w-full pl-9 pr-4 py-2 bg-muted border-0 rounded-full text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                autoFocus
              />
            </div>
            <button
              type="button"
              onClick={() => {
                setShowSearch(false)
                setSearchQuery('')
              }}
              className="p-2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </form>
        ) : (
          <>
            <Link href="/" className="flex items-center gap-2">
              <BookOpen className="h-7 w-7 text-primary" />
              <span className="text-lg font-bold text-foreground">Sözlüks</span>
            </Link>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowSearch(true)}
                className="p-2 text-muted-foreground hover:text-foreground transition-colors"
              >
                <Search className="h-5 w-5" />
              </button>
              <button
                onClick={toggleTheme}
                className="p-2 text-muted-foreground hover:text-foreground transition-colors"
              >
                {resolvedTheme === 'dark' ? (
                  <Sun className="h-5 w-5" />
                ) : (
                  <Moon className="h-5 w-5" />
                )}
              </button>
              {user ? (
                <Link
                  href="/profile"
                  className={cn(
                    'w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-colors',
                    'bg-primary/10 text-primary hover:bg-primary/20'
                  )}
                >
                  {profile?.display_name?.[0]?.toUpperCase() || profile?.username?.[0]?.toUpperCase() || 'U'}
                </Link>
              ) : (
                <Link
                  href="/auth/login"
                  className="p-2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  <LogIn className="h-5 w-5" />
                </Link>
              )}
            </div>
          </>
        )}
      </div>
    </header>
  )
}
