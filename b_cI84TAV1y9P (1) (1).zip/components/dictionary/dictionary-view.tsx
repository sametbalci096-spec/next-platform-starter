'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Search, Plus, BookOpen, Users, User, Heart, Play, Video } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import { useAuth } from '@/lib/context/auth-context'
import { EmptyState } from '@/components/ui/empty-state'
import { formatDistanceToNow, cn, slugify } from '@/lib/utils'
import type { CommunityWordWithProfile, PersonalWord } from '@/lib/types/database'

interface DictionaryViewProps {
  initialWords: CommunityWordWithProfile[]
}

type Tab = 'community' | 'personal'

export function DictionaryView({ initialWords }: DictionaryViewProps) {
  const [activeTab, setActiveTab] = useState<Tab>('community')
  const [communityWords, setCommunityWords] = useState<CommunityWordWithProfile[]>(initialWords)
  const [personalWords, setPersonalWords] = useState<PersonalWord[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [showAddModal, setShowAddModal] = useState(false)
  const [newWord, setNewWord] = useState('')
  const [newDefinition, setNewDefinition] = useState('')
  const [newVideoUrl, setNewVideoUrl] = useState('')
  const [loading, setLoading] = useState(false)
  const [personalLoaded, setPersonalLoaded] = useState(false)

  const { user } = useAuth()
  const supabase = createClient()

  const loadPersonalWords = async () => {
    if (!user || personalLoaded) return
    
    const { data } = await supabase
      .from('personal_words')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
    
    setPersonalWords(data || [])
    setPersonalLoaded(true)
  }

  const handleTabChange = async (tab: Tab) => {
    setActiveTab(tab)
    if (tab === 'personal') {
      await loadPersonalWords()
    }
  }

  const handleSearch = async () => {
    if (!searchQuery.trim()) return

    if (activeTab === 'community') {
      const { data } = await supabase
        .from('community_words')
        .select(`*, profiles:created_by(*), community_word_likes(user_id)`)
        .ilike('word', `%${searchQuery}%`)
        .limit(20)
      
      setCommunityWords(data || [])
    } else if (user) {
      const { data } = await supabase
        .from('personal_words')
        .select('*')
        .eq('user_id', user.id)
        .ilike('word', `%${searchQuery}%`)
      
      setPersonalWords(data || [])
    }
  }

  const handleAddWord = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !newWord.trim() || !newDefinition.trim()) return

    setLoading(true)

    try {
      if (activeTab === 'community') {
        const { data, error } = await supabase
          .from('community_words')
          .insert({
            word: newWord.trim(),
            slug: slugify(newWord.trim()),
            definition: newDefinition.trim(),
            video_url: newVideoUrl.trim() || null,
            created_by: user.id,
          })
          .select(`*, profiles:created_by(*), community_word_likes(user_id)`)
          .single()

        if (!error && data) {
          setCommunityWords([data as CommunityWordWithProfile, ...communityWords])
        }
      } else {
        const { data, error } = await supabase
          .from('personal_words')
          .insert({
            user_id: user.id,
            word: newWord.trim(),
            definition: newDefinition.trim(),
            video_url: newVideoUrl.trim() || null,
          })
          .select()
          .single()

        if (!error && data) {
          setPersonalWords([data, ...personalWords])
        }
      }

      setShowAddModal(false)
      setNewWord('')
      setNewDefinition('')
      setNewVideoUrl('')
    } catch (err) {
      console.error('Error adding word:', err)
    } finally {
      setLoading(false)
    }
  }

  const handleLike = async (wordId: string, isLiked: boolean) => {
    if (!user) return

    if (isLiked) {
      await supabase
        .from('community_word_likes')
        .delete()
        .eq('word_id', wordId)
        .eq('user_id', user.id)
    } else {
      await supabase
        .from('community_word_likes')
        .insert({ word_id: wordId, user_id: user.id })
    }

    setCommunityWords(communityWords.map(w => {
      if (w.id === wordId) {
        const newLikeCount = isLiked ? w.like_count - 1 : w.like_count + 1
        const newLikes = isLiked
          ? w.community_word_likes?.filter(l => l.user_id !== user.id)
          : [...(w.community_word_likes || []), { user_id: user.id }]
        return { ...w, like_count: newLikeCount, community_word_likes: newLikes }
      }
      return w
    }))
  }

  const filteredCommunityWords = communityWords.filter(w =>
    w.word.toLowerCase().includes(searchQuery.toLowerCase())
  )
  
  const filteredPersonalWords = personalWords.filter(w =>
    w.word.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="max-w-2xl mx-auto">
      <div className="sticky top-14 md:top-0 z-30 bg-card/80 backdrop-blur-lg border-b border-border">
        <div className="flex items-center justify-between px-4 py-3">
          <h1 className="text-lg font-bold text-foreground">Sözlük</h1>
          {user && (
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-2 px-3 py-1.5 bg-primary text-primary-foreground rounded-full text-sm font-medium hover:bg-primary/90 transition-colors"
            >
              <Plus className="h-4 w-4" />
              <span className="hidden sm:inline">Kelime Ekle</span>
            </button>
          )}
        </div>

        <div className="px-4 pb-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              placeholder="Kelime ara..."
              className="w-full pl-10 pr-4 py-2.5 bg-muted border-0 rounded-full text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
          </div>
        </div>

        <div className="flex">
          <button
            onClick={() => handleTabChange('community')}
            className={cn(
              'flex-1 py-3 text-sm font-medium border-b-2 transition-colors',
              activeTab === 'community'
                ? 'text-primary border-primary'
                : 'text-muted-foreground border-transparent hover:text-foreground'
            )}
          >
            <Users className="h-4 w-4 inline mr-2" />
            Topluluk
          </button>
          <button
            onClick={() => handleTabChange('personal')}
            className={cn(
              'flex-1 py-3 text-sm font-medium border-b-2 transition-colors',
              activeTab === 'personal'
                ? 'text-primary border-primary'
                : 'text-muted-foreground border-transparent hover:text-foreground'
            )}
          >
            <User className="h-4 w-4 inline mr-2" />
            Kişisel
          </button>
        </div>
      </div>

      {activeTab === 'community' ? (
        filteredCommunityWords.length === 0 ? (
          <EmptyState
            icon={BookOpen}
            title="Kelime bulunamadı"
            description="Topluluk sözlüğünde henüz kelime yok veya aramanızla eşleşen sonuç bulunamadı."
            action={user ? { label: 'Kelime Ekle', onClick: () => setShowAddModal(true) } : undefined}
          />
        ) : (
          <div className="divide-y divide-border">
            {filteredCommunityWords.map((word) => {
              const isLiked = word.community_word_likes?.some(l => l.user_id === user?.id)
              
              return (
                <div key={word.id} className="p-4 hover:bg-muted/30 transition-colors">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-lg font-semibold text-foreground">{word.word}</h3>
                    <button
                      onClick={() => handleLike(word.id, isLiked ?? false)}
                      disabled={!user}
                      className={cn(
                        'flex items-center gap-1 text-sm transition-colors',
                        isLiked ? 'text-red-500' : 'text-muted-foreground hover:text-red-500',
                        !user && 'cursor-not-allowed opacity-50'
                      )}
                    >
                      <Heart className={cn('h-4 w-4', isLiked && 'fill-current')} />
                      <span>{word.like_count}</span>
                    </button>
                  </div>
                  <p className="text-foreground mb-2">{word.definition}</p>
                  {word.video_url && (
                    <div className="relative aspect-video bg-muted rounded-lg overflow-hidden mb-2 max-w-md">
                      {word.video_url.includes('youtube.com') || word.video_url.includes('youtu.be') ? (
                        <iframe
                          src={word.video_url.replace('watch?v=', 'embed/').replace('youtu.be/', 'youtube.com/embed/')}
                          className="w-full h-full"
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                          allowFullScreen
                        />
                      ) : (
                        <video src={word.video_url} controls className="w-full h-full object-cover">
                          <track kind="captions" />
                        </video>
                      )}
                    </div>
                  )}
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    {word.profiles && (
                      <Link href={`/user/${word.profiles.username}`} className="hover:underline">
                        @{word.profiles.username}
                      </Link>
                    )}
                    <span>·</span>
                    <span>{formatDistanceToNow(word.created_at)}</span>
                  </div>
                </div>
              )
            })}
          </div>
        )
      ) : !user ? (
        <EmptyState
          icon={User}
          title="Giriş yapın"
          description="Kişisel sözlüğünüzü görüntülemek için giriş yapmalısınız."
          action={{ label: 'Giriş Yap', href: '/auth/login' }}
        />
      ) : filteredPersonalWords.length === 0 ? (
        <EmptyState
          icon={BookOpen}
          title="Kişisel sözlüğünüz boş"
          description="Kendi kelimelerinizi ekleyerek kişisel sözlüğünüzü oluşturun."
          action={{ label: 'Kelime Ekle', onClick: () => setShowAddModal(true) }}
        />
      ) : (
        <div className="divide-y divide-border">
          {filteredPersonalWords.map((word) => (
            <div key={word.id} className="p-4 hover:bg-muted/30 transition-colors">
              <h3 className="text-lg font-semibold text-foreground mb-2">{word.word}</h3>
              <p className="text-foreground mb-2">{word.definition}</p>
              {word.video_url && (
                <div className="relative aspect-video bg-muted rounded-lg overflow-hidden mb-2 max-w-md">
                  {word.video_url.includes('youtube.com') || word.video_url.includes('youtu.be') ? (
                    <iframe
                      src={word.video_url.replace('watch?v=', 'embed/').replace('youtu.be/', 'youtube.com/embed/')}
                      className="w-full h-full"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  ) : (
                    <video src={word.video_url} controls className="w-full h-full object-cover">
                      <track kind="captions" />
                    </video>
                  )}
                </div>
              )}
              <p className="text-sm text-muted-foreground">{formatDistanceToNow(word.created_at)}</p>
            </div>
          ))}
        </div>
      )}

      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-md bg-card rounded-xl shadow-lg border border-border p-6">
            <h2 className="text-xl font-bold text-foreground mb-4">
              {activeTab === 'community' ? 'Topluluk Sözlüğüne' : 'Kişisel Sözlüğe'} Kelime Ekle
            </h2>
            <form onSubmit={handleAddWord} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">Kelime</label>
                <input
                  type="text"
                  value={newWord}
                  onChange={(e) => setNewWord(e.target.value)}
                  placeholder="Kelime"
                  className="w-full px-4 py-2.5 bg-input border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">Tanım</label>
                <textarea
                  value={newDefinition}
                  onChange={(e) => setNewDefinition(e.target.value)}
                  placeholder="Tanım"
                  rows={3}
                  className="w-full px-4 py-2.5 bg-input border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors resize-none"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">
                  Video URL (isteğe bağlı)
                </label>
                <input
                  type="url"
                  value={newVideoUrl}
                  onChange={(e) => setNewVideoUrl(e.target.value)}
                  placeholder="https://youtube.com/watch?v=..."
                  className="w-full px-4 py-2.5 bg-input border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors"
                />
              </div>
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 border border-border rounded-lg font-medium text-foreground hover:bg-muted transition-colors"
                >
                  İptal
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 py-2.5 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 disabled:opacity-50 transition-colors"
                >
                  {loading ? 'Ekleniyor...' : 'Ekle'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
