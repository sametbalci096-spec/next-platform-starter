'use client'

import { useState } from 'react'
import Link from 'next/link'
import { EntryCard } from '@/components/entry/entry-card'
import { EmptyState } from '@/components/ui/empty-state'
import { TrendingUp, MessageSquare, Hash } from 'lucide-react'
import { cn, formatNumber } from '@/lib/utils'
import type { EntryWithRelations, Topic } from '@/lib/types/database'

interface TrendingFeedProps {
  entries: EntryWithRelations[]
  topics: Topic[]
}

type Tab = 'entries' | 'topics'

export function TrendingFeed({ entries, topics }: TrendingFeedProps) {
  const [activeTab, setActiveTab] = useState<Tab>('entries')

  return (
    <div className="max-w-2xl mx-auto">
      <div className="sticky top-14 md:top-0 z-30 bg-card/80 backdrop-blur-lg border-b border-border">
        <div className="px-4 py-3">
          <h1 className="text-lg font-bold text-foreground">Trend</h1>
        </div>
        <div className="flex">
          <button
            onClick={() => setActiveTab('entries')}
            className={cn(
              'flex-1 py-3 text-sm font-medium border-b-2 transition-colors',
              activeTab === 'entries'
                ? 'text-primary border-primary'
                : 'text-muted-foreground border-transparent hover:text-foreground'
            )}
          >
            <MessageSquare className="h-4 w-4 inline mr-2" />
            Entry&apos;ler
          </button>
          <button
            onClick={() => setActiveTab('topics')}
            className={cn(
              'flex-1 py-3 text-sm font-medium border-b-2 transition-colors',
              activeTab === 'topics'
                ? 'text-primary border-primary'
                : 'text-muted-foreground border-transparent hover:text-foreground'
            )}
          >
            <Hash className="h-4 w-4 inline mr-2" />
            Başlıklar
          </button>
        </div>
      </div>

      {activeTab === 'entries' ? (
        entries.length === 0 ? (
          <EmptyState
            icon={TrendingUp}
            title="Henüz trend entry yok"
            description="İlk popüler entry&apos;yi oluşturun!"
          />
        ) : (
          <div className="divide-y divide-border">
            {entries.map((entry) => (
              <EntryCard key={entry.id} entry={entry} />
            ))}
          </div>
        )
      ) : (
        topics.length === 0 ? (
          <EmptyState
            icon={Hash}
            title="Henüz trend başlık yok"
            description="İlk başlığı oluşturarak başlayın!"
          />
        ) : (
          <div className="divide-y divide-border">
            {topics.map((topic, index) => (
              <Link
                key={topic.id}
                href={`/topic/${topic.slug}`}
                className="flex items-center gap-4 p-4 hover:bg-muted/30 transition-colors"
              >
                <span className="text-2xl font-bold text-muted-foreground w-8">
                  {index + 1}
                </span>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-foreground truncate">{topic.title}</h3>
                  {topic.definition && (
                    <p className="text-sm text-muted-foreground truncate">{topic.definition}</p>
                  )}
                  <p className="text-sm text-muted-foreground mt-1">
                    {formatNumber(topic.entry_count)} entry · {formatNumber(topic.view_count)} görüntülenme
                  </p>
                </div>
                <TrendingUp className="h-5 w-5 text-primary shrink-0" />
              </Link>
            ))}
          </div>
        )
      )}
    </div>
  )
}
