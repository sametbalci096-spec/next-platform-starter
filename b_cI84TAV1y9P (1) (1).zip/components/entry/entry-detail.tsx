'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { ArrowLeft, Heart, MessageCircle, Share2, Send } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import { useAuth } from '@/lib/context/auth-context'
import { formatDistanceToNow, cn } from '@/lib/utils'
import type { EntryWithRelations, CommentWithProfile } from '@/lib/types/database'

interface EntryDetailProps {
  entry: EntryWithRelations
  initialComments: CommentWithProfile[]
}

export function EntryDetail({ entry, initialComments }: EntryDetailProps) {
  const { user } = useAuth()
  const router = useRouter()
  const supabase = createClient()

  const [likeCount, setLikeCount] = useState(entry.like_count)
  const [isLiked, setIsLiked] = useState(
    entry.likes?.some((like) => like.user_id === user?.id) ?? false
  )
  const [isLiking, setIsLiking] = useState(false)
  const [comments, setComments] = useState<CommentWithProfile[]>(initialComments)
  const [newComment, setNewComment] = useState('')
  const [submittingComment, setSubmittingComment] = useState(false)

  useEffect(() => {
    const channel = supabase
      .channel(`entry-${entry.id}-comments`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'comments',
          filter: `entry_id=eq.${entry.id}`,
        },
        async (payload) => {
          const { data: newCommentData } = await supabase
            .from('comments')
            .select(`*, profiles:user_id(*)`)
            .eq('id', payload.new.id)
            .single()

          if (newCommentData) {
            setComments((prev) => [...prev, newCommentData as CommentWithProfile])
          }
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [supabase, entry.id])

  const handleLike = async () => {
    if (!user || isLiking) return

    setIsLiking(true)

    if (isLiked) {
      setLikeCount((prev) => prev - 1)
      setIsLiked(false)
      await supabase.from('likes').delete().eq('entry_id', entry.id).eq('user_id', user.id)
    } else {
      setLikeCount((prev) => prev + 1)
      setIsLiked(true)
      await supabase.from('likes').insert({ entry_id: entry.id, user_id: user.id })
    }

    setIsLiking(false)
  }

  const handleShare = async () => {
    const url = window.location.href

    if (navigator.share) {
      await navigator.share({
        title: entry.topics.title,
        text: entry.content.slice(0, 100),
        url,
      })
    } else {
      await navigator.clipboard.writeText(url)
    }
  }

  const handleSubmitComment = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !newComment.trim() || submittingComment) return

    setSubmittingComment(true)

    const { error } = await supabase.from('comments').insert({
      entry_id: entry.id,
      user_id: user.id,
      content: newComment.trim(),
    })

    if (!error) {
      setNewComment('')
    }

    setSubmittingComment(false)
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="sticky top-14 md:top-0 z-30 bg-card/80 backdrop-blur-lg border-b border-border">
        <div className="flex items-center gap-3 px-4 py-3">
          <button
            onClick={() => router.back()}
            className="p-1 -ml-1 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <h1 className="text-lg font-bold text-foreground">Entry</h1>
        </div>
      </div>

      <article className="p-4 border-b border-border">
        <Link
          href={`/topic/${entry.topics.slug}`}
          className="inline-block text-primary font-semibold text-xl hover:underline mb-3"
        >
          {entry.topics.title}
        </Link>

        {entry.topics.definition && (
          <p className="text-muted-foreground text-sm mb-4 italic">
            {entry.topics.definition}
          </p>
        )}

        <div className="flex items-start gap-3 mb-4">
          <Link href={`/user/${entry.profiles.username}`} className="shrink-0">
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center text-primary font-medium text-lg">
              {entry.profiles.display_name?.[0]?.toUpperCase() ||
                entry.profiles.username[0].toUpperCase()}
            </div>
          </Link>

          <div className="flex-1">
            <Link
              href={`/user/${entry.profiles.username}`}
              className="font-medium text-foreground hover:underline"
            >
              {entry.profiles.display_name || entry.profiles.username}
            </Link>
            <p className="text-sm text-muted-foreground">@{entry.profiles.username}</p>
          </div>
        </div>

        <p className="text-foreground text-lg leading-relaxed whitespace-pre-wrap mb-4">
          {entry.content}
        </p>

        {entry.video_url && (
          <div className="relative aspect-video bg-muted rounded-xl overflow-hidden mb-4">
            {entry.video_url.includes('youtube.com') || entry.video_url.includes('youtu.be') ? (
              <iframe
                src={entry.video_url
                  .replace('watch?v=', 'embed/')
                  .replace('youtu.be/', 'youtube.com/embed/')}
                className="w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            ) : (
              <video src={entry.video_url} controls className="w-full h-full object-cover">
                <track kind="captions" />
              </video>
            )}
          </div>
        )}

        <p className="text-sm text-muted-foreground mb-4">
          {new Date(entry.created_at).toLocaleDateString('tr-TR', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
          })}
        </p>

        <div className="flex items-center gap-6 pt-4 border-t border-border text-muted-foreground">
          <button
            onClick={handleLike}
            disabled={!user}
            className={cn(
              'flex items-center gap-2 transition-colors',
              isLiked ? 'text-red-500' : 'hover:text-red-500',
              !user && 'cursor-not-allowed opacity-50'
            )}
          >
            <Heart className={cn('h-6 w-6', isLiked && 'fill-current')} />
            <span className="font-medium">{likeCount}</span>
          </button>

          <div className="flex items-center gap-2">
            <MessageCircle className="h-6 w-6" />
            <span className="font-medium">{comments.length}</span>
          </div>

          <button onClick={handleShare} className="hover:text-primary transition-colors">
            <Share2 className="h-6 w-6" />
          </button>
        </div>
      </article>

      <div className="p-4 border-b border-border">
        <h2 className="font-semibold text-foreground mb-4">Yorumlar</h2>

        {user ? (
          <form onSubmit={handleSubmitComment} className="flex items-start gap-3 mb-6">
            <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary font-medium shrink-0">
              {user.user_metadata?.full_name?.[0]?.toUpperCase() || 'U'}
            </div>
            <div className="flex-1 relative">
              <textarea
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Yorumunuzu yazın..."
                rows={2}
                className="w-full px-4 py-2.5 pr-12 bg-input border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors resize-none"
              />
              <button
                type="submit"
                disabled={!newComment.trim() || submittingComment}
                className="absolute right-2 bottom-2 p-2 text-primary hover:bg-primary/10 rounded-full disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <Send className="h-5 w-5" />
              </button>
            </div>
          </form>
        ) : (
          <p className="text-muted-foreground text-sm mb-6">
            Yorum yapmak için{' '}
            <Link href="/auth/login" className="text-primary hover:underline">
              giriş yapın
            </Link>
          </p>
        )}

        <div className="space-y-4">
          {comments.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">Henüz yorum yok</p>
          ) : (
            comments.map((comment) => (
              <div key={comment.id} className="flex items-start gap-3">
                <Link href={`/user/${comment.profiles.username}`} className="shrink-0">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary font-medium">
                    {comment.profiles.display_name?.[0]?.toUpperCase() ||
                      comment.profiles.username[0].toUpperCase()}
                  </div>
                </Link>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <Link
                      href={`/user/${comment.profiles.username}`}
                      className="font-medium text-foreground hover:underline"
                    >
                      {comment.profiles.display_name || comment.profiles.username}
                    </Link>
                    <span className="text-sm text-muted-foreground">
                      {formatDistanceToNow(comment.created_at)}
                    </span>
                  </div>
                  <p className="text-foreground whitespace-pre-wrap">{comment.content}</p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
