'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Heart, MessageCircle, Share2, Play, MoreHorizontal } from 'lucide-react'
import { formatDistanceToNow } from '@/lib/utils'
import { createClient } from '@/lib/supabase/client'
import { useAuth } from '@/lib/context/auth-context'
import type { EntryWithRelations } from '@/lib/types/database'
import { cn } from '@/lib/utils'

interface EntryCardProps {
  entry: EntryWithRelations
  showTopic?: boolean
}

export function EntryCard({ entry, showTopic = true }: EntryCardProps) {
  const { user } = useAuth()
  const [likeCount, setLikeCount] = useState(entry.like_count)
  const [isLiked, setIsLiked] = useState(
    entry.likes?.some((like) => like.user_id === user?.id) ?? false
  )
  const [isLiking, setIsLiking] = useState(false)
  const supabase = createClient()

  const handleLike = async () => {
    if (!user || isLiking) return
    
    setIsLiking(true)
    
    if (isLiked) {
      setLikeCount((prev) => prev - 1)
      setIsLiked(false)
      
      await supabase
        .from('likes')
        .delete()
        .eq('entry_id', entry.id)
        .eq('user_id', user.id)
    } else {
      setLikeCount((prev) => prev + 1)
      setIsLiked(true)
      
      await supabase
        .from('likes')
        .insert({ entry_id: entry.id, user_id: user.id })
    }
    
    setIsLiking(false)
  }

  const handleShare = async () => {
    const url = `${window.location.origin}/entry/${entry.id}`
    
    if (navigator.share) {
      await navigator.share({
        title: entry.topics.title,
        text: entry.content.slice(0, 100),
        url,
      })
    } else {
      await navigator.clipboard.writeText(url)
    }
  }

  return (
    <article className="bg-card border-b border-border p-4 hover:bg-muted/30 transition-colors">
      {showTopic && (
        <Link 
          href={`/topic/${entry.topics.slug}`}
          className="inline-block text-primary font-semibold hover:underline mb-2"
        >
          {entry.topics.title}
        </Link>
      )}
      
      <div className="flex items-start gap-3 mb-3">
        <Link href={`/user/${entry.profiles.username}`} className="shrink-0">
          <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary font-medium">
            {entry.profiles.display_name?.[0]?.toUpperCase() || entry.profiles.username[0].toUpperCase()}
          </div>
        </Link>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 text-sm">
            <Link 
              href={`/user/${entry.profiles.username}`}
              className="font-medium text-foreground hover:underline"
            >
              {entry.profiles.display_name || entry.profiles.username}
            </Link>
            <span className="text-muted-foreground">@{entry.profiles.username}</span>
            <span className="text-muted-foreground">·</span>
            <span className="text-muted-foreground">
              {formatDistanceToNow(entry.created_at)}
            </span>
          </div>
        </div>

        <button className="p-1 text-muted-foreground hover:text-foreground transition-colors">
          <MoreHorizontal className="h-5 w-5" />
        </button>
      </div>

      <Link href={`/entry/${entry.id}`}>
        <p className="text-foreground leading-relaxed whitespace-pre-wrap mb-3">
          {entry.content}
        </p>
      </Link>

      {entry.video_url && (
        <div className="relative aspect-video bg-muted rounded-xl overflow-hidden mb-3">
          {entry.video_url.includes('youtube.com') || entry.video_url.includes('youtu.be') ? (
            <iframe
              src={entry.video_url.replace('watch?v=', 'embed/').replace('youtu.be/', 'youtube.com/embed/')}
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          ) : (
            <video 
              src={entry.video_url} 
              controls 
              className="w-full h-full object-cover"
              preload="metadata"
            >
              <track kind="captions" />
            </video>
          )}
        </div>
      )}

      <div className="flex items-center gap-6 text-muted-foreground">
        <button
          onClick={handleLike}
          disabled={!user}
          className={cn(
            'flex items-center gap-1.5 transition-colors',
            isLiked ? 'text-red-500' : 'hover:text-red-500',
            !user && 'cursor-not-allowed opacity-50'
          )}
        >
          <Heart className={cn('h-5 w-5', isLiked && 'fill-current')} />
          <span className="text-sm">{likeCount}</span>
        </button>

        <Link 
          href={`/entry/${entry.id}`}
          className="flex items-center gap-1.5 hover:text-primary transition-colors"
        >
          <MessageCircle className="h-5 w-5" />
          <span className="text-sm">{entry.comment_count}</span>
        </Link>

        <button
          onClick={handleShare}
          className="flex items-center gap-1.5 hover:text-primary transition-colors"
        >
          <Share2 className="h-5 w-5" />
        </button>
      </div>
    </article>
  )
}
