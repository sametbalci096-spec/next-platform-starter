'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { EntryCard } from '@/components/entry/entry-card'
import { EmptyState } from '@/components/ui/empty-state'
import { LoadingFeed } from '@/components/ui/loading'
import { PenLine, Plus } from 'lucide-react'
import Link from 'next/link'
import type { EntryWithRelations } from '@/lib/types/database'
import { useAuth } from '@/lib/context/auth-context'

interface HomeFeedProps {
  initialEntries: EntryWithRelations[]
}

export function HomeFeed({ initialEntries }: HomeFeedProps) {
  const [entries, setEntries] = useState<EntryWithRelations[]>(initialEntries)
  const [loading, setLoading] = useState(false)
  const { user } = useAuth()
  const supabase = createClient()

  useEffect(() => {
    const channel = supabase
      .channel('entries-realtime')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'entries',
        },
        async (payload) => {
          const { data: newEntry } = await supabase
            .from('entries')
            .select(`
              *,
              profiles:user_id(*),
              topics:topic_id(*),
              likes(user_id)
            `)
            .eq('id', payload.new.id)
            .single()

          if (newEntry) {
            setEntries((prev) => [newEntry as EntryWithRelations, ...prev])
          }
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [supabase])

  if (loading) {
    return <LoadingFeed />
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="sticky top-14 md:top-0 z-30 bg-card/80 backdrop-blur-lg border-b border-border">
        <div className="flex items-center justify-between px-4 py-3">
          <h1 className="text-lg font-bold text-foreground">Ana Sayfa</h1>
          {user && (
            <Link
              href="/entry/new"
              className="flex items-center gap-2 px-3 py-1.5 bg-primary text-primary-foreground rounded-full text-sm font-medium hover:bg-primary/90 transition-colors"
            >
              <Plus className="h-4 w-4" />
              <span className="hidden sm:inline">Yeni Entry</span>
            </Link>
          )}
        </div>
      </div>

      {entries.length === 0 ? (
        <EmptyState
          icon={PenLine}
          title="Henüz entry yok"
          description="İlk entry&apos;yi oluşturarak topluluğu başlatın!"
          action={user ? { label: 'Entry Oluştur', href: '/entry/new' } : { label: 'Giriş Yap', href: '/auth/login' }}
        />
      ) : (
        <div className="divide-y divide-border">
          {entries.map((entry) => (
            <EntryCard key={entry.id} entry={entry} />
          ))}
        </div>
      )}
    </div>
  )
}
