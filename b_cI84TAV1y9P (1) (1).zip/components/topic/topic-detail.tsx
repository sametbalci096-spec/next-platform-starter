'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { ArrowLeft, Plus, BookOpen, Eye, MessageSquare } from 'lucide-react'
import { EntryCard } from '@/components/entry/entry-card'
import { EmptyState } from '@/components/ui/empty-state'
import { useAuth } from '@/lib/context/auth-context'
import { formatNumber } from '@/lib/utils'
import type { Topic, EntryWithRelations } from '@/lib/types/database'

interface TopicDetailProps {
  topic: Topic
  entries: EntryWithRelations[]
}

export function TopicDetail({ topic, entries }: TopicDetailProps) {
  const { user } = useAuth()
  const router = useRouter()

  return (
    <div className="max-w-2xl mx-auto">
      <div className="sticky top-14 md:top-0 z-30 bg-card/80 backdrop-blur-lg border-b border-border">
        <div className="flex items-center gap-3 px-4 py-3">
          <button
            onClick={() => router.back()}
            className="p-1 -ml-1 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <h1 className="text-lg font-bold text-foreground truncate">{topic.title}</h1>
        </div>
      </div>

      <div className="p-4 border-b border-border bg-card">
        <h2 className="text-2xl font-bold text-foreground mb-2">{topic.title}</h2>
        
        {topic.definition && (
          <div className="flex items-start gap-2 p-3 bg-muted/50 rounded-lg mb-4">
            <BookOpen className="h-5 w-5 text-primary shrink-0 mt-0.5" />
            <p className="text-muted-foreground">{topic.definition}</p>
          </div>
        )}

        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <span className="flex items-center gap-1">
            <MessageSquare className="h-4 w-4" />
            {formatNumber(topic.entry_count)} entry
          </span>
          <span className="flex items-center gap-1">
            <Eye className="h-4 w-4" />
            {formatNumber(topic.view_count)} görüntülenme
          </span>
        </div>

        {user && (
          <Link
            href={`/entry/new?topic=${topic.slug}`}
            className="inline-flex items-center gap-2 mt-4 px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors"
          >
            <Plus className="h-4 w-4" />
            Entry Yaz
          </Link>
        )}
      </div>

      {entries.length === 0 ? (
        <EmptyState
          icon={MessageSquare}
          title="Henüz entry yok"
          description="Bu başlık altında ilk entry&apos;yi siz yazın!"
          action={user ? { label: 'Entry Yaz', href: `/entry/new?topic=${topic.slug}` } : undefined}
        />
      ) : (
        <div className="divide-y divide-border">
          {entries.map((entry) => (
            <EntryCard key={entry.id} entry={entry} showTopic={false} />
          ))}
        </div>
      )}
    </div>
  )
}
