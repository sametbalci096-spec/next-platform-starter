'use client'

import { EntryCard } from '@/components/entry/entry-card'
import { EmptyState } from '@/components/ui/empty-state'
import { Users } from 'lucide-react'
import type { EntryWithRelations } from '@/lib/types/database'

interface FollowingFeedProps {
  initialEntries: EntryWithRelations[]
}

export function FollowingFeed({ initialEntries }: FollowingFeedProps) {
  return (
    <div className="max-w-2xl mx-auto">
      <div className="sticky top-14 md:top-0 z-30 bg-card/80 backdrop-blur-lg border-b border-border">
        <div className="px-4 py-3">
          <h1 className="text-lg font-bold text-foreground">Takip Ettiklerim</h1>
        </div>
      </div>

      {initialEntries.length === 0 ? (
        <EmptyState
          icon={Users}
          title="Henüz entry yok"
          description="Takip ettiğiniz kullanıcıların entry&apos;leri burada görünecek. Keşfetmeye başlayın!"
          action={{ label: 'Keşfet', href: '/trending' }}
        />
      ) : (
        <div className="divide-y divide-border">
          {initialEntries.map((entry) => (
            <EntryCard key={entry.id} entry={entry} />
          ))}
        </div>
      )}
    </div>
  )
}
