'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { ArrowLeft, Users } from 'lucide-react'
import { EmptyState } from '@/components/ui/empty-state'
import type { Profile } from '@/lib/types/database'

interface FollowListProps {
  title: string
  username: string
  users: Profile[]
  emptyMessage: string
}

export function FollowList({ title, username, users, emptyMessage }: FollowListProps) {
  const router = useRouter()

  return (
    <div className="max-w-2xl mx-auto">
      <div className="sticky top-14 md:top-0 z-30 bg-card/80 backdrop-blur-lg border-b border-border">
        <div className="flex items-center gap-3 px-4 py-3">
          <button
            onClick={() => router.back()}
            className="p-1 -ml-1 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-lg font-bold text-foreground">{title}</h1>
            <p className="text-sm text-muted-foreground">@{username}</p>
          </div>
        </div>
      </div>

      {users.length === 0 ? (
        <EmptyState
          icon={Users}
          title="Henüz kimse yok"
          description={emptyMessage}
        />
      ) : (
        <div className="divide-y divide-border">
          {users.map((user) => (
            <Link
              key={user.id}
              href={`/user/${user.username}`}
              className="flex items-center gap-3 p-4 hover:bg-muted/30 transition-colors"
            >
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center text-primary font-medium text-lg">
                {user.display_name?.[0]?.toUpperCase() || user.username[0].toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-foreground truncate">
                  {user.display_name || user.username}
                </h3>
                <p className="text-sm text-muted-foreground">@{user.username}</p>
                {user.bio && (
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{user.bio}</p>
                )}
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}
