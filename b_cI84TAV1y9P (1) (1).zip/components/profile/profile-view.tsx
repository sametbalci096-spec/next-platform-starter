'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { ArrowLeft, Settings, Calendar, Edit, LogOut, UserPlus, UserMinus } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import { useAuth } from '@/lib/context/auth-context'
import { EntryCard } from '@/components/entry/entry-card'
import { EmptyState } from '@/components/ui/empty-state'
import { formatNumber } from '@/lib/utils'
import type { Profile, EntryWithRelations } from '@/lib/types/database'

interface ProfileViewProps {
  profile: Profile
  entries: EntryWithRelations[]
  followersCount: number
  followingCount: number
  isOwnProfile: boolean
  isFollowing?: boolean
}

export function ProfileView({
  profile,
  entries,
  followersCount: initialFollowersCount,
  followingCount,
  isOwnProfile,
  isFollowing: initialIsFollowing = false,
}: ProfileViewProps) {
  const router = useRouter()
  const { user, signOut } = useAuth()
  const supabase = createClient()

  const [isFollowing, setIsFollowing] = useState(initialIsFollowing)
  const [followersCount, setFollowersCount] = useState(initialFollowersCount)
  const [isFollowLoading, setIsFollowLoading] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [editDisplayName, setEditDisplayName] = useState(profile.display_name || '')
  const [editBio, setEditBio] = useState(profile.bio || '')
  const [isSaving, setIsSaving] = useState(false)

  const handleFollow = async () => {
    if (!user || isFollowLoading) return

    setIsFollowLoading(true)

    if (isFollowing) {
      await supabase
        .from('follows')
        .delete()
        .eq('follower_id', user.id)
        .eq('following_id', profile.id)

      setIsFollowing(false)
      setFollowersCount((prev) => prev - 1)
    } else {
      await supabase.from('follows').insert({
        follower_id: user.id,
        following_id: profile.id,
      })

      setIsFollowing(true)
      setFollowersCount((prev) => prev + 1)
    }

    setIsFollowLoading(false)
  }

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    setIsSaving(true)

    await supabase
      .from('profiles')
      .update({
        display_name: editDisplayName.trim() || null,
        bio: editBio.trim() || null,
        updated_at: new Date().toISOString(),
      })
      .eq('id', user.id)

    setShowEditModal(false)
    router.refresh()
    setIsSaving(false)
  }

  const handleSignOut = async () => {
    await signOut()
    router.push('/')
    router.refresh()
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="sticky top-14 md:top-0 z-30 bg-card/80 backdrop-blur-lg border-b border-border">
        <div className="flex items-center gap-3 px-4 py-3">
          <button
            onClick={() => router.back()}
            className="p-1 -ml-1 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-lg font-bold text-foreground">
              {profile.display_name || profile.username}
            </h1>
            <p className="text-sm text-muted-foreground">{entries.length} entry</p>
          </div>
        </div>
      </div>

      <div className="p-4 border-b border-border">
        <div className="flex items-start justify-between mb-4">
          <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center text-primary font-bold text-3xl">
            {profile.display_name?.[0]?.toUpperCase() || profile.username[0].toUpperCase()}
          </div>

          {isOwnProfile ? (
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowEditModal(true)}
                className="flex items-center gap-2 px-4 py-2 border border-border rounded-full font-medium text-foreground hover:bg-muted transition-colors"
              >
                <Edit className="h-4 w-4" />
                Düzenle
              </button>
              <button
                onClick={handleSignOut}
                className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-full transition-colors"
                title="Çıkış Yap"
              >
                <LogOut className="h-5 w-5" />
              </button>
            </div>
          ) : user && user.id !== profile.id ? (
            <button
              onClick={handleFollow}
              disabled={isFollowLoading}
              className={
                isFollowing
                  ? 'flex items-center gap-2 px-4 py-2 border border-border rounded-full font-medium text-foreground hover:border-destructive hover:text-destructive transition-colors'
                  : 'flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-full font-medium hover:bg-primary/90 transition-colors'
              }
            >
              {isFollowing ? (
                <>
                  <UserMinus className="h-4 w-4" />
                  Takibi Bırak
                </>
              ) : (
                <>
                  <UserPlus className="h-4 w-4" />
                  Takip Et
                </>
              )}
            </button>
          ) : null}
        </div>

        <h2 className="text-xl font-bold text-foreground">
          {profile.display_name || profile.username}
        </h2>
        <p className="text-muted-foreground">@{profile.username}</p>

        {profile.bio && <p className="text-foreground mt-3">{profile.bio}</p>}

        <div className="flex items-center gap-4 mt-4 text-sm">
          <Link href={`/user/${profile.username}/following`} className="hover:underline">
            <span className="font-semibold text-foreground">{formatNumber(followingCount)}</span>{' '}
            <span className="text-muted-foreground">Takip</span>
          </Link>
          <Link href={`/user/${profile.username}/followers`} className="hover:underline">
            <span className="font-semibold text-foreground">{formatNumber(followersCount)}</span>{' '}
            <span className="text-muted-foreground">Takipçi</span>
          </Link>
        </div>

        <div className="flex items-center gap-2 mt-4 text-sm text-muted-foreground">
          <Calendar className="h-4 w-4" />
          <span>
            {new Date(profile.created_at).toLocaleDateString('tr-TR', {
              year: 'numeric',
              month: 'long',
            })}{' '}
            tarihinde katıldı
          </span>
        </div>
      </div>

      {entries.length === 0 ? (
        <EmptyState
          icon={Edit}
          title="Henüz entry yok"
          description={
            isOwnProfile
              ? "İlk entry'nizi yazarak başlayın!"
              : 'Bu kullanıcı henüz entry yazmamış.'
          }
          action={isOwnProfile ? { label: 'Entry Yaz', href: '/entry/new' } : undefined}
        />
      ) : (
        <div className="divide-y divide-border">
          {entries.map((entry) => (
            <EntryCard key={entry.id} entry={entry} />
          ))}
        </div>
      )}

      {showEditModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-md bg-card rounded-xl shadow-lg border border-border p-6">
            <h2 className="text-xl font-bold text-foreground mb-4">Profili Düzenle</h2>
            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">
                  Görünen Ad
                </label>
                <input
                  type="text"
                  value={editDisplayName}
                  onChange={(e) => setEditDisplayName(e.target.value)}
                  placeholder="Adınız"
                  className="w-full px-4 py-2.5 bg-input border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">Biyografi</label>
                <textarea
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  placeholder="Kendiniz hakkında bir şeyler yazın..."
                  rows={3}
                  className="w-full px-4 py-2.5 bg-input border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors resize-none"
                />
              </div>
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="flex-1 py-2.5 border border-border rounded-lg font-medium text-foreground hover:bg-muted transition-colors"
                >
                  İptal
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="flex-1 py-2.5 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 disabled:opacity-50 transition-colors"
                >
                  {isSaving ? 'Kaydediliyor...' : 'Kaydet'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
