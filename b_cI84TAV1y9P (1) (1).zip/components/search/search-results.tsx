'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Search, Hash, MessageSquare, User } from 'lucide-react'
import { EntryCard } from '@/components/entry/entry-card'
import { EmptyState } from '@/components/ui/empty-state'
import { cn, formatNumber } from '@/lib/utils'
import type { Topic, EntryWithRelations, Profile } from '@/lib/types/database'

interface SearchResultsProps {
  query: string
  topics: Topic[]
  entries: EntryWithRelations[]
  users: Profile[]
}

type Tab = 'all' | 'topics' | 'entries' | 'users'

export function SearchResults({ query, topics, entries, users }: SearchResultsProps) {
  const [activeTab, setActiveTab] = useState<Tab>('all')

  const totalResults = topics.length + entries.length + users.length

  if (!query) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="sticky top-14 md:top-0 z-30 bg-card/80 backdrop-blur-lg border-b border-border">
          <div className="px-4 py-3">
            <h1 className="text-lg font-bold text-foreground">Arama</h1>
          </div>
        </div>
        <EmptyState
          icon={Search}
          title="Arama yapın"
          description="Başlık, entry veya kullanıcı aramak için arama çubuğunu kullanın."
        />
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="sticky top-14 md:top-0 z-30 bg-card/80 backdrop-blur-lg border-b border-border">
        <div className="px-4 py-3">
          <h1 className="text-lg font-bold text-foreground">
            &quot;{query}&quot; için sonuçlar
          </h1>
          <p className="text-sm text-muted-foreground">{totalResults} sonuç bulundu</p>
        </div>
        <div className="flex overflow-x-auto">
          {[
            { key: 'all' as const, label: 'Tümü', count: totalResults },
            { key: 'topics' as const, label: 'Başlıklar', count: topics.length },
            { key: 'entries' as const, label: "Entry'ler", count: entries.length },
            { key: 'users' as const, label: 'Kullanıcılar', count: users.length },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'flex-shrink-0 px-4 py-3 text-sm font-medium border-b-2 transition-colors',
                activeTab === tab.key
                  ? 'text-primary border-primary'
                  : 'text-muted-foreground border-transparent hover:text-foreground'
              )}
            >
              {tab.label} ({tab.count})
            </button>
          ))}
        </div>
      </div>

      {totalResults === 0 ? (
        <EmptyState
          icon={Search}
          title="Sonuç bulunamadı"
          description={`"${query}" ile eşleşen sonuç bulunamadı. Farklı anahtar kelimeler deneyin.`}
        />
      ) : (
        <div className="divide-y divide-border">
          {(activeTab === 'all' || activeTab === 'topics') &&
            topics.map((topic) => (
              <Link
                key={topic.id}
                href={`/topic/${topic.slug}`}
                className="flex items-center gap-3 p-4 hover:bg-muted/30 transition-colors"
              >
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                  <Hash className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium text-foreground truncate">{topic.title}</h3>
                  {topic.definition && (
                    <p className="text-sm text-muted-foreground truncate">{topic.definition}</p>
                  )}
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {formatNumber(topic.entry_count)} entry
                  </p>
                </div>
              </Link>
            ))}

          {(activeTab === 'all' || activeTab === 'entries') &&
            entries.map((entry) => <EntryCard key={entry.id} entry={entry} />)}

          {(activeTab === 'all' || activeTab === 'users') &&
            users.map((user) => (
              <Link
                key={user.id}
                href={`/user/${user.username}`}
                className="flex items-center gap-3 p-4 hover:bg-muted/30 transition-colors"
              >
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary font-medium">
                  {user.display_name?.[0]?.toUpperCase() || user.username[0].toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium text-foreground truncate">
                    {user.display_name || user.username}
                  </h3>
                  <p className="text-sm text-muted-foreground">@{user.username}</p>
                </div>
              </Link>
            ))}
        </div>
      )}
    </div>
  )
}
