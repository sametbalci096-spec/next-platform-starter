import { NextRequest, NextResponse } from 'next/server'

const LANGUAGES = ['tr', 'en', 'de']

// Simple translation using a free translation approach
// In production, you would use a proper translation API like DeepL or Google Translate
async function translateText(text: string, targetLang: string): Promise<string> {
  try {
    // Using LibreTranslate (free and open source)
    const response = await fetch('https://libretranslate.com/translate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        q: text,
        source: 'auto',
        target: targetLang,
        format: 'text',
      }),
    })

    if (response.ok) {
      const data = await response.json()
      return data.translatedText
    }
  } catch (error) {
    console.error(`Translation to ${targetLang} failed:`, error)
  }

  // Fallback: return original text with language indicator
  const langNames: Record<string, string> = {
    tr: 'Türkçe',
    en: 'English',
    de: 'Deutsch',
  }
  
  return `[${langNames[targetLang] || targetLang}] ${text}`
}

export async function POST(request: NextRequest) {
  try {
    const { text } = await request.json()

    if (!text || typeof text !== 'string') {
      return NextResponse.json(
        { error: 'Text is required' },
        { status: 400 }
      )
    }

    // Translate to all target languages in parallel
    const translations = await Promise.all(
      LANGUAGES.map(async (lang) => ({
        lang,
        text: await translateText(text.trim(), lang),
      }))
    )

    return NextResponse.json({ translations })
  } catch (error) {
    console.error('Translation error:', error)
    return NextResponse.json(
      { error: 'Translation failed' },
      { status: 500 }
    )
  }
}
