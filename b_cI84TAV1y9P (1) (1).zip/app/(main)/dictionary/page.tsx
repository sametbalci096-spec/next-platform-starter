import { createClient } from '@/lib/supabase/server'
import { DictionaryView } from '@/components/dictionary/dictionary-view'

export default async function DictionaryPage() {
  const supabase = await createClient()

  const { data: communityWords } = await supabase
    .from('community_words')
    .select(`
      *,
      profiles:created_by(*),
      community_word_likes(user_id)
    `)
    .order('like_count', { ascending: false })
    .limit(20)

  return <DictionaryView initialWords={communityWords || []} />
}
