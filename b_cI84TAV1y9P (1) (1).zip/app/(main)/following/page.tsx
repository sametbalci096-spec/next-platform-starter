import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { FollowingFeed } from '@/components/following/following-feed'

export default async function FollowingPage() {
  const supabase = await createClient()
  
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) {
    redirect('/auth/login')
  }

  const { data: follows } = await supabase
    .from('follows')
    .select('following_id')
    .eq('follower_id', user.id)

  const followingIds = follows?.map(f => f.following_id) || []

  let entries: any[] = []
  if (followingIds.length > 0) {
    const { data } = await supabase
      .from('entries')
      .select(`
        *,
        profiles:user_id(*),
        topics:topic_id(*),
        likes(user_id)
      `)
      .in('user_id', followingIds)
      .order('created_at', { ascending: false })
      .limit(20)
    
    entries = data || []
  }

  return <FollowingFeed initialEntries={entries} />
}
