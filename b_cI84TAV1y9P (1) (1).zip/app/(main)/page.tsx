import { createClient } from '@/lib/supabase/server'
import { HomeFeed } from '@/components/home/home-feed'

export default async function HomePage() {
  const supabase = await createClient()
  
  const { data: entries } = await supabase
    .from('entries')
    .select(`
      *,
      profiles:user_id(*),
      topics:topic_id(*),
      likes(user_id)
    `)
    .order('created_at', { ascending: false })
    .limit(20)

  return <HomeFeed initialEntries={entries || []} />
}
