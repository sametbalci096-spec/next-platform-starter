import { createClient } from '@/lib/supabase/server'
import { TrendingFeed } from '@/components/trending/trending-feed'

export default async function TrendingPage() {
  const supabase = await createClient()

  const { data: trendingEntries } = await supabase
    .from('entries')
    .select(`
      *,
      profiles:user_id(*),
      topics:topic_id(*),
      likes(user_id)
    `)
    .order('like_count', { ascending: false })
    .order('comment_count', { ascending: false })
    .limit(20)

  const { data: trendingTopics } = await supabase
    .from('topics')
    .select('*')
    .order('entry_count', { ascending: false })
    .order('view_count', { ascending: false })
    .limit(10)

  return (
    <TrendingFeed
      entries={trendingEntries || []}
      topics={trendingTopics || []}
    />
  )
}
