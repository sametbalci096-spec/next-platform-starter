import { createClient } from '@/lib/supabase/server'
import { notFound } from 'next/navigation'
import { TopicDetail } from '@/components/topic/topic-detail'

interface TopicPageProps {
  params: Promise<{ slug: string }>
}

export default async function TopicPage({ params }: TopicPageProps) {
  const { slug } = await params
  const supabase = await createClient()

  const { data: topic } = await supabase
    .from('topics')
    .select('*')
    .eq('slug', slug)
    .single()

  if (!topic) {
    notFound()
  }

  // Increment view count
  await supabase
    .from('topics')
    .update({ view_count: topic.view_count + 1 })
    .eq('id', topic.id)

  const { data: entries } = await supabase
    .from('entries')
    .select(`
      *,
      profiles:user_id(*),
      topics:topic_id(*),
      likes(user_id)
    `)
    .eq('topic_id', topic.id)
    .order('created_at', { ascending: false })

  return <TopicDetail topic={topic} entries={entries || []} />
}
