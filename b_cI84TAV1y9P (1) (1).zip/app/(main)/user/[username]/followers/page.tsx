import { createClient } from '@/lib/supabase/server'
import { notFound } from 'next/navigation'
import { FollowList } from '@/components/profile/follow-list'

interface FollowersPageProps {
  params: Promise<{ username: string }>
}

export default async function FollowersPage({ params }: FollowersPageProps) {
  const { username } = await params
  const supabase = await createClient()

  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('username', username)
    .single()

  if (!profile) {
    notFound()
  }

  const { data: followers } = await supabase
    .from('follows')
    .select(`
      follower:follower_id(*)
    `)
    .eq('following_id', profile.id)

  const followerProfiles = followers?.map(f => f.follower).filter(Boolean) || []

  return (
    <FollowList
      title="Takipçiler"
      username={profile.username}
      users={followerProfiles}
      emptyMessage={`@${profile.username} henüz takipçi kazanmamış.`}
    />
  )
}
