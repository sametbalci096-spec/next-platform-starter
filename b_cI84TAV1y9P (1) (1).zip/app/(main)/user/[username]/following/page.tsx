import { createClient } from '@/lib/supabase/server'
import { notFound } from 'next/navigation'
import { FollowList } from '@/components/profile/follow-list'

interface FollowingPageProps {
  params: Promise<{ username: string }>
}

export default async function FollowingPage({ params }: FollowingPageProps) {
  const { username } = await params
  const supabase = await createClient()

  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('username', username)
    .single()

  if (!profile) {
    notFound()
  }

  const { data: following } = await supabase
    .from('follows')
    .select(`
      following:following_id(*)
    `)
    .eq('follower_id', profile.id)

  const followingProfiles = following?.map(f => f.following).filter(Boolean) || []

  return (
    <FollowList
      title="Takip Edilenler"
      username={profile.username}
      users={followingProfiles}
      emptyMessage={`@${profile.username} henüz kimseyi takip etmiyor.`}
    />
  )
}
