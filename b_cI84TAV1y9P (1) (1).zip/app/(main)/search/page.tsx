import { createClient } from '@/lib/supabase/server'
import { SearchResults } from '@/components/search/search-results'

interface SearchPageProps {
  searchParams: Promise<{ q?: string }>
}

export default async function SearchPage({ searchParams }: SearchPageProps) {
  const { q } = await searchParams
  const supabase = await createClient()

  let topics: any[] = []
  let entries: any[] = []
  let users: any[] = []

  if (q && q.trim()) {
    const searchQuery = q.trim()

    const [topicsResult, entriesResult, usersResult] = await Promise.all([
      supabase
        .from('topics')
        .select('*')
        .ilike('title', `%${searchQuery}%`)
        .limit(10),
      supabase
        .from('entries')
        .select(`
          *,
          profiles:user_id(*),
          topics:topic_id(*),
          likes(user_id)
        `)
        .ilike('content', `%${searchQuery}%`)
        .limit(10),
      supabase
        .from('profiles')
        .select('*')
        .or(`username.ilike.%${searchQuery}%,display_name.ilike.%${searchQuery}%`)
        .limit(10),
    ])

    topics = topicsResult.data || []
    entries = entriesResult.data || []
    users = usersResult.data || []
  }

  return (
    <SearchResults
      query={q || ''}
      topics={topics}
      entries={entries}
      users={users}
    />
  )
}
