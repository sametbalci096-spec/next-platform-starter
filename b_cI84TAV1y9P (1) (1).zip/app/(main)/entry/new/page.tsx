'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { useAuth } from '@/lib/context/auth-context'
import { slugify } from '@/lib/utils'
import { ArrowLeft, Video, X, Search } from 'lucide-react'
import Link from 'next/link'
import type { Topic } from '@/lib/types/database'

export default function NewEntryPage() {
  const [content, setContent] = useState('')
  const [videoUrl, setVideoUrl] = useState('')
  const [showVideo, setShowVideo] = useState(false)
  const [topicSearch, setTopicSearch] = useState('')
  const [selectedTopic, setSelectedTopic] = useState<Topic | null>(null)
  const [topics, setTopics] = useState<Topic[]>([])
  const [newTopicTitle, setNewTopicTitle] = useState('')
  const [newTopicDefinition, setNewTopicDefinition] = useState('')
  const [showNewTopic, setShowNewTopic] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  
  const router = useRouter()
  const { user } = useAuth()
  const supabase = createClient()

  useEffect(() => {
    if (!user) {
      router.push('/auth/login')
    }
  }, [user, router])

  useEffect(() => {
    const searchTopics = async () => {
      if (topicSearch.length < 2) {
        setTopics([])
        return
      }

      const { data } = await supabase
        .from('topics')
        .select('*')
        .ilike('title', `%${topicSearch}%`)
        .limit(10)

      setTopics(data || [])
    }

    const debounce = setTimeout(searchTopics, 300)
    return () => clearTimeout(debounce)
  }, [topicSearch, supabase])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    setLoading(true)
    setError(null)

    try {
      let topicId = selectedTopic?.id

      if (showNewTopic && newTopicTitle) {
        const slug = slugify(newTopicTitle)
        
        const { data: existingTopic } = await supabase
          .from('topics')
          .select('id')
          .eq('slug', slug)
          .single()

        if (existingTopic) {
          topicId = existingTopic.id
        } else {
          const { data: newTopic, error: topicError } = await supabase
            .from('topics')
            .insert({
              title: newTopicTitle,
              slug,
              definition: newTopicDefinition || null,
              created_by: user.id,
            })
            .select()
            .single()

          if (topicError) throw topicError
          topicId = newTopic.id
        }
      }

      if (!topicId) {
        setError('Lütfen bir başlık seçin veya yeni başlık oluşturun')
        setLoading(false)
        return
      }

      const { error: entryError } = await supabase
        .from('entries')
        .insert({
          topic_id: topicId,
          user_id: user.id,
          content,
          video_url: showVideo && videoUrl ? videoUrl : null,
        })

      if (entryError) throw entryError

      router.push('/')
      router.refresh()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Bir hata oluştu')
    } finally {
      setLoading(false)
    }
  }

  if (!user) return null

  return (
    <div className="max-w-2xl mx-auto">
      <div className="sticky top-14 md:top-0 z-30 bg-card/80 backdrop-blur-lg border-b border-border">
        <div className="flex items-center gap-3 px-4 py-3">
          <Link href="/" className="p-1 -ml-1 text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <h1 className="text-lg font-bold text-foreground">Yeni Entry</h1>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="p-4 space-y-4">
        {!showNewTopic ? (
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">
              Başlık Seç
            </label>
            {selectedTopic ? (
              <div className="flex items-center justify-between p-3 bg-primary/10 border border-primary/20 rounded-lg">
                <span className="font-medium text-foreground">{selectedTopic.title}</span>
                <button
                  type="button"
                  onClick={() => setSelectedTopic(null)}
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <input
                  type="text"
                  value={topicSearch}
                  onChange={(e) => setTopicSearch(e.target.value)}
                  placeholder="Başlık ara..."
                  className="w-full pl-10 pr-4 py-2.5 bg-input border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors"
                />
                {topics.length > 0 && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-card border border-border rounded-lg shadow-lg overflow-hidden z-10">
                    {topics.map((topic) => (
                      <button
                        key={topic.id}
                        type="button"
                        onClick={() => {
                          setSelectedTopic(topic)
                          setTopicSearch('')
                          setTopics([])
                        }}
                        className="w-full px-4 py-2.5 text-left hover:bg-muted transition-colors"
                      >
                        <span className="font-medium text-foreground">{topic.title}</span>
                        <span className="text-sm text-muted-foreground ml-2">
                          ({topic.entry_count} entry)
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
            <button
              type="button"
              onClick={() => setShowNewTopic(true)}
              className="mt-2 text-sm text-primary hover:underline"
            >
              Yeni başlık oluştur
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">
                Yeni Başlık
              </label>
              <input
                type="text"
                value={newTopicTitle}
                onChange={(e) => setNewTopicTitle(e.target.value)}
                placeholder="Başlık adı"
                className="w-full px-4 py-2.5 bg-input border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">
                Tanım (isteğe bağlı)
              </label>
              <input
                type="text"
                value={newTopicDefinition}
                onChange={(e) => setNewTopicDefinition(e.target.value)}
                placeholder="Bu başlığın sözlük tanımı"
                className="w-full px-4 py-2.5 bg-input border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors"
              />
            </div>
            <button
              type="button"
              onClick={() => {
                setShowNewTopic(false)
                setNewTopicTitle('')
                setNewTopicDefinition('')
              }}
              className="text-sm text-primary hover:underline"
            >
              Mevcut başlık seç
            </button>
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">
            Entry İçeriği
          </label>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Düşüncelerinizi yazın..."
            rows={6}
            className="w-full px-4 py-2.5 bg-input border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors resize-none"
            required
          />
        </div>

        {showVideo ? (
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-sm font-medium text-foreground">
                Video URL
              </label>
              <button
                type="button"
                onClick={() => {
                  setShowVideo(false)
                  setVideoUrl('')
                }}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                Kaldır
              </button>
            </div>
            <input
              type="url"
              value={videoUrl}
              onChange={(e) => setVideoUrl(e.target.value)}
              placeholder="https://youtube.com/watch?v=..."
              className="w-full px-4 py-2.5 bg-input border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-colors"
            />
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setShowVideo(true)}
            className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <Video className="h-4 w-4" />
            Video ekle
          </button>
        )}

        {error && (
          <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg text-destructive text-sm">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={loading || !content.trim() || (!selectedTopic && !newTopicTitle)}
          className="w-full py-2.5 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {loading ? 'Paylaşılıyor...' : 'Paylaş'}
        </button>
      </form>
    </div>
  )
}
