import { createClient } from '@/lib/supabase/server'
import { notFound } from 'next/navigation'
import { EntryDetail } from '@/components/entry/entry-detail'

interface EntryPageProps {
  params: Promise<{ id: string }>
}

export default async function EntryPage({ params }: EntryPageProps) {
  const { id } = await params
  const supabase = await createClient()

  const { data: entry } = await supabase
    .from('entries')
    .select(`
      *,
      profiles:user_id(*),
      topics:topic_id(*),
      likes(user_id)
    `)
    .eq('id', id)
    .single()

  if (!entry) {
    notFound()
  }

  const { data: comments } = await supabase
    .from('comments')
    .select(`
      *,
      profiles:user_id(*)
    `)
    .eq('entry_id', id)
    .order('created_at', { ascending: true })

  return <EntryDetail entry={entry} initialComments={comments || []} />
}
