'use client'

import { useState } from 'react'
import { Languages, ArrowRight, Copy, Check, RefreshCw } from 'lucide-react'
import { cn } from '@/lib/utils'

const LANGUAGES = [
  { code: 'tr', name: 'Türkçe', flag: '🇹🇷' },
  { code: 'en', name: 'İngilizce', flag: '🇬🇧' },
  { code: 'de', name: 'Almanca', flag: '🇩🇪' },
]

interface Translation {
  lang: string
  text: string
}

export default function TranslatePage() {
  const [inputText, setInputText] = useState('')
  const [translations, setTranslations] = useState<Translation[]>([])
  const [loading, setLoading] = useState(false)
  const [copiedLang, setCopiedLang] = useState<string | null>(null)

  const handleTranslate = async () => {
    if (!inputText.trim()) return

    setLoading(true)
    setTranslations([])

    try {
      const response = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: inputText }),
      })

      const data = await response.json()
      
      if (data.translations) {
        setTranslations(data.translations)
      }
    } catch (error) {
      console.error('Translation error:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleCopy = async (text: string, lang: string) => {
    await navigator.clipboard.writeText(text)
    setCopiedLang(lang)
    setTimeout(() => setCopiedLang(null), 2000)
  }

  const handleClear = () => {
    setInputText('')
    setTranslations([])
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="sticky top-14 md:top-0 z-30 bg-card/80 backdrop-blur-lg border-b border-border">
        <div className="px-4 py-3">
          <h1 className="text-lg font-bold text-foreground">Çeviri</h1>
          <p className="text-sm text-muted-foreground">Türkçe, İngilizce ve Almanca arasında çeviri yapın</p>
        </div>
      </div>

      <div className="p-4 space-y-6">
        <div className="bg-card border border-border rounded-xl p-4">
          <div className="flex items-center gap-2 mb-3">
            <Languages className="h-5 w-5 text-primary" />
            <span className="font-medium text-foreground">Metin Girin</span>
          </div>
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Çevirmek istediğiniz metni yazın..."
            rows={4}
            className="w-full px-4 py-3 bg-muted border-0 rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
          />
          <div className="flex items-center justify-between mt-3">
            <button
              onClick={handleClear}
              disabled={!inputText && translations.length === 0}
              className="text-sm text-muted-foreground hover:text-foreground disabled:opacity-50 transition-colors"
            >
              Temizle
            </button>
            <button
              onClick={handleTranslate}
              disabled={!inputText.trim() || loading}
              className={cn(
                'flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium transition-colors',
                'hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed'
              )}
            >
              {loading ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  Çevriliyor...
                </>
              ) : (
                <>
                  <ArrowRight className="h-4 w-4" />
                  Çevir
                </>
              )}
            </button>
          </div>
        </div>

        {translations.length > 0 && (
          <div className="space-y-4">
            <h2 className="font-semibold text-foreground">Çeviriler</h2>
            {translations.map((translation) => {
              const lang = LANGUAGES.find(l => l.code === translation.lang)
              return (
                <div
                  key={translation.lang}
                  className="bg-card border border-border rounded-xl p-4"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{lang?.flag}</span>
                      <span className="font-medium text-foreground">{lang?.name}</span>
                    </div>
                    <button
                      onClick={() => handleCopy(translation.text, translation.lang)}
                      className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {copiedLang === translation.lang ? (
                        <>
                          <Check className="h-4 w-4 text-primary" />
                          Kopyalandı
                        </>
                      ) : (
                        <>
                          <Copy className="h-4 w-4" />
                          Kopyala
                        </>
                      )}
                    </button>
                  </div>
                  <p className="text-foreground whitespace-pre-wrap">{translation.text}</p>
                </div>
              )
            })}
          </div>
        )}

        {!translations.length && !loading && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <Languages className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="font-semibold text-foreground mb-2">Çeviri Yapın</h3>
            <p className="text-muted-foreground max-w-sm mx-auto">
              Yukarıya metin girin ve çevir butonuna tıklayın. Metin otomatik olarak 
              Türkçe, İngilizce ve Almanca dillerine çevrilecektir.
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
