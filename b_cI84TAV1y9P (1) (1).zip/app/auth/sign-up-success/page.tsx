import Link from 'next/link'
import { BookOpen, Mail, ArrowLeft } from 'lucide-react'

export default function SignUpSuccessPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="w-full max-w-md text-center">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-4">
            <BookOpen className="h-10 w-10 text-primary" />
            <span className="text-3xl font-bold text-foreground">Sözlüks</span>
          </Link>
        </div>

        <div className="bg-card rounded-xl shadow-lg border border-border p-8">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <Mail className="h-8 w-8 text-primary" />
          </div>
          
          <h1 className="text-2xl font-bold text-foreground mb-3">
            E-postanızı Kontrol Edin
          </h1>
          
          <p className="text-muted-foreground mb-6 leading-relaxed">
            Hesabınızı doğrulamak için e-posta adresinize bir onay bağlantısı gönderdik. 
            Lütfen gelen kutunuzu kontrol edin ve bağlantıya tıklayın.
          </p>

          <div className="bg-muted/50 rounded-lg p-4 mb-6">
            <p className="text-sm text-muted-foreground">
              E-postayı bulamıyor musunuz? Spam klasörünü de kontrol etmeyi unutmayın.
            </p>
          </div>

          <Link
            href="/auth/login"
            className="inline-flex items-center gap-2 text-primary hover:underline font-medium"
          >
            <ArrowLeft className="h-4 w-4" />
            Giriş sayfasına dön
          </Link>
        </div>
      </div>
    </div>
  )
}
