import Link from 'next/link'
import { BookOpen, AlertCircle, ArrowLeft } from 'lucide-react'

export default function AuthErrorPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="w-full max-w-md text-center">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-4">
            <BookOpen className="h-10 w-10 text-primary" />
            <span className="text-3xl font-bold text-foreground">Sözlüks</span>
          </Link>
        </div>

        <div className="bg-card rounded-xl shadow-lg border border-border p-8">
          <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <AlertCircle className="h-8 w-8 text-destructive" />
          </div>
          
          <h1 className="text-2xl font-bold text-foreground mb-3">
            Bir Hata Oluştu
          </h1>
          
          <p className="text-muted-foreground mb-6 leading-relaxed">
            Kimlik doğrulama sırasında bir sorun oluştu. Lütfen tekrar deneyin.
          </p>

          <div className="flex flex-col gap-3">
            <Link
              href="/auth/login"
              className="w-full py-2.5 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors"
            >
              Tekrar Dene
            </Link>
            
            <Link
              href="/"
              className="inline-flex items-center justify-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              Ana sayfaya dön
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
