-- Function to update entry like count
CREATE OR REPLACE FUNCTION public.update_entry_like_count()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.entries SET like_count = like_count + 1 WHERE id = NEW.entry_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.entries SET like_count = like_count - 1 WHERE id = OLD.entry_id;
  END IF;
  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS on_like_change ON public.likes;
CREATE TRIGGER on_like_change
  AFTER INSERT OR DELETE ON public.likes
  FOR EACH ROW
  EXECUTE FUNCTION public.update_entry_like_count();

-- Function to update entry comment count
CREATE OR REPLACE FUNCTION public.update_entry_comment_count()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.entries SET comment_count = comment_count + 1 WHERE id = NEW.entry_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.entries SET comment_count = comment_count - 1 WHERE id = OLD.entry_id;
  END IF;
  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS on_comment_change ON public.comments;
CREATE TRIGGER on_comment_change
  AFTER INSERT OR DELETE ON public.comments
  FOR EACH ROW
  EXECUTE FUNCTION public.update_entry_comment_count();

-- Function to update topic entry count
CREATE OR REPLACE FUNCTION public.update_topic_entry_count()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.topics SET entry_count = entry_count + 1 WHERE id = NEW.topic_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.topics SET entry_count = entry_count - 1 WHERE id = OLD.topic_id;
  END IF;
  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS on_entry_change ON public.entries;
CREATE TRIGGER on_entry_change
  AFTER INSERT OR DELETE ON public.entries
  FOR EACH ROW
  EXECUTE FUNCTION public.update_topic_entry_count();

-- Function to update community word like count
CREATE OR REPLACE FUNCTION public.update_community_word_like_count()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.community_words SET like_count = like_count + 1 WHERE id = NEW.word_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.community_words SET like_count = like_count - 1 WHERE id = OLD.word_id;
  END IF;
  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS on_community_word_like_change ON public.community_word_likes;
CREATE TRIGGER on_community_word_like_change
  AFTER INSERT OR DELETE ON public.community_word_likes
  FOR EACH ROW
  EXECUTE FUNCTION public.update_community_word_like_count();

-- Helper function to generate slug
CREATE OR REPLACE FUNCTION public.generate_slug(title TEXT)
RETURNS TEXT
LANGUAGE plpgsql
AS $$
DECLARE
  slug TEXT;
BEGIN
  slug := LOWER(title);
  slug := REGEXP_REPLACE(slug, '[^a-z0-9\s-]', '', 'g');
  slug := REGEXP_REPLACE(slug, '\s+', '-', 'g');
  slug := REGEXP_REPLACE(slug, '-+', '-', 'g');
  slug := TRIM(BOTH '-' FROM slug);
  RETURN slug;
END;
$$;

-- Enable realtime for relevant tables
ALTER PUBLICATION supabase_realtime ADD TABLE public.entries;
ALTER PUBLICATION supabase_realtime ADD TABLE public.comments;
ALTER PUBLICATION supabase_realtime ADD TABLE public.likes;
ALTER PUBLICATION supabase_realtime ADD TABLE public.follows;
ALTER PUBLICATION supabase_realtime ADD TABLE public.community_words;
ALTER PUBLICATION supabase_realtime ADD TABLE public.community_word_likes;
