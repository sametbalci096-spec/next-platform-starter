-- Sözlüks Database Schema
-- Users/Profiles table
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT UNIQUE NOT NULL,
  display_name TEXT,
  avatar_url TEXT,
  bio TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Topics/Başlıklar table (words/subjects that users can write entries about)
CREATE TABLE IF NOT EXISTS public.topics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL UNIQUE,
  slug TEXT NOT NULL UNIQUE,
  definition TEXT, -- Dictionary definition
  created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  entry_count INTEGER DEFAULT 0,
  view_count INTEGER DEFAULT 0
);

-- Entries table (user entries under topics)
CREATE TABLE IF NOT EXISTS public.entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  topic_id UUID NOT NULL REFERENCES public.topics(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  video_url TEXT,
  like_count INTEGER DEFAULT 0,
  comment_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Comments table
CREATE TABLE IF NOT EXISTS public.comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entry_id UUID NOT NULL REFERENCES public.entries(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Likes table
CREATE TABLE IF NOT EXISTS public.likes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entry_id UUID NOT NULL REFERENCES public.entries(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(entry_id, user_id)
);

-- Follows table
CREATE TABLE IF NOT EXISTS public.follows (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  following_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(follower_id, following_id),
  CHECK (follower_id != following_id)
);

-- Personal Dictionary Words
CREATE TABLE IF NOT EXISTS public.personal_words (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  word TEXT NOT NULL,
  definition TEXT NOT NULL,
  video_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, word)
);

-- Community Dictionary Words
CREATE TABLE IF NOT EXISTS public.community_words (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  word TEXT NOT NULL UNIQUE,
  slug TEXT NOT NULL UNIQUE,
  definition TEXT NOT NULL,
  video_url TEXT,
  created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  like_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Community Dictionary Likes
CREATE TABLE IF NOT EXISTS public.community_word_likes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  word_id UUID NOT NULL REFERENCES public.community_words(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(word_id, user_id)
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_entries_topic_id ON public.entries(topic_id);
CREATE INDEX IF NOT EXISTS idx_entries_user_id ON public.entries(user_id);
CREATE INDEX IF NOT EXISTS idx_entries_created_at ON public.entries(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_comments_entry_id ON public.comments(entry_id);
CREATE INDEX IF NOT EXISTS idx_likes_entry_id ON public.likes(entry_id);
CREATE INDEX IF NOT EXISTS idx_likes_user_id ON public.likes(user_id);
CREATE INDEX IF NOT EXISTS idx_follows_follower ON public.follows(follower_id);
CREATE INDEX IF NOT EXISTS idx_follows_following ON public.follows(following_id);
CREATE INDEX IF NOT EXISTS idx_topics_slug ON public.topics(slug);
CREATE INDEX IF NOT EXISTS idx_personal_words_user ON public.personal_words(user_id);
CREATE INDEX IF NOT EXISTS idx_community_words_slug ON public.community_words(slug);

-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.topics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.follows ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.personal_words ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.community_words ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.community_word_likes ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "profiles_select_all" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "profiles_insert_own" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "profiles_delete_own" ON public.profiles FOR DELETE USING (auth.uid() = id);

-- Topics policies
CREATE POLICY "topics_select_all" ON public.topics FOR SELECT USING (true);
CREATE POLICY "topics_insert_auth" ON public.topics FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY "topics_update_own" ON public.topics FOR UPDATE USING (auth.uid() = created_by);
CREATE POLICY "topics_delete_own" ON public.topics FOR DELETE USING (auth.uid() = created_by);

-- Entries policies
CREATE POLICY "entries_select_all" ON public.entries FOR SELECT USING (true);
CREATE POLICY "entries_insert_auth" ON public.entries FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "entries_update_own" ON public.entries FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "entries_delete_own" ON public.entries FOR DELETE USING (auth.uid() = user_id);

-- Comments policies
CREATE POLICY "comments_select_all" ON public.comments FOR SELECT USING (true);
CREATE POLICY "comments_insert_auth" ON public.comments FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "comments_update_own" ON public.comments FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "comments_delete_own" ON public.comments FOR DELETE USING (auth.uid() = user_id);

-- Likes policies
CREATE POLICY "likes_select_all" ON public.likes FOR SELECT USING (true);
CREATE POLICY "likes_insert_auth" ON public.likes FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "likes_delete_own" ON public.likes FOR DELETE USING (auth.uid() = user_id);

-- Follows policies
CREATE POLICY "follows_select_all" ON public.follows FOR SELECT USING (true);
CREATE POLICY "follows_insert_auth" ON public.follows FOR INSERT WITH CHECK (auth.uid() = follower_id);
CREATE POLICY "follows_delete_own" ON public.follows FOR DELETE USING (auth.uid() = follower_id);

-- Personal words policies
CREATE POLICY "personal_words_select_own" ON public.personal_words FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "personal_words_insert_own" ON public.personal_words FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "personal_words_update_own" ON public.personal_words FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "personal_words_delete_own" ON public.personal_words FOR DELETE USING (auth.uid() = user_id);

-- Community words policies
CREATE POLICY "community_words_select_all" ON public.community_words FOR SELECT USING (true);
CREATE POLICY "community_words_insert_auth" ON public.community_words FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY "community_words_update_own" ON public.community_words FOR UPDATE USING (auth.uid() = created_by);
CREATE POLICY "community_words_delete_own" ON public.community_words FOR DELETE USING (auth.uid() = created_by);

-- Community word likes policies
CREATE POLICY "community_word_likes_select_all" ON public.community_word_likes FOR SELECT USING (true);
CREATE POLICY "community_word_likes_insert_auth" ON public.community_word_likes FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "community_word_likes_delete_own" ON public.community_word_likes FOR DELETE USING (auth.uid() = user_id);
